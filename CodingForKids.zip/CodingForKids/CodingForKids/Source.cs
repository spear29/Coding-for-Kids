﻿//CODING FOR KIDS | Fall 2018 | Developers: Zach, Sinan, Alexander, Hao, Todd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingForKids
{
    //
    class CodingForKids
    {
        int q = 1;
        Database datab = new Database();

        public void NewGame()
        {
            foreach (string question in datab.questions)
            {
                Console.WriteLine(question);
            }
        }
    }

    // 3 choice lines per 1 question line/1 answers line
    class Database
    {
        public string[] questions;
        public string[] choices;
        public string[] answers;

        public void Load()
        {
            questions = System.IO.File.ReadAllLines(@"C:\Games\CodingForKids\CodingForKids\questions.txt");
            choices = System.IO.File.ReadAllLines(@"C:\Games\CodingForKids\CodingForKids\choices.txt");
            answers = System.IO.File.ReadAllLines(@"C:\Games\CodingForKids\CodingForKids\answers.txt");
        }

        public void Display()
        {
           /* foreach (string question in questions)
            {
                Console.WriteLine(question);
            }*/

            /*
             How to access answers.txt based on question number N

             i = 1;
             if(n == 1)
                return i;
             else
             {
                for(int j = 2; j <= n; j++)
                {
                    i += 3;
                }
             }
             */
        }
    }

    //
    class Interface
    {

    }

    //
    class Tutorial
    {

    }

    //
    class ExecuteGame
    {
        static void Main(string[] args)
        {
            //INTERFACE
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1()); //Form1 is Interface.cs, For some reason it didnt change.
            //INTERFACE
            Database d = new Database();
            CodingForKids g = new CodingForKids();
            d.Load();
            //d.Display();
            g.NewGame();
            Console.ReadKey(); // Hold the window.
        }
    }
}